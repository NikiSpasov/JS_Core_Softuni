let mapSort = require("./mapSort.js").mapSort;
result.mapSort = mapSort;
